// Function to submit a comment
function submitComment() {
  var commentInput = document.getElementById('commentInput');
  var comment = commentInput.value.trim();
  if (comment !== '') {
    var commentList = document.getElementById('commentList');
    var listItem = document.createElement('li');
    listItem.textContent = comment;
    commentList.appendChild(listItem);
    // Clear the input field
    commentInput.value = '';
  }
}
